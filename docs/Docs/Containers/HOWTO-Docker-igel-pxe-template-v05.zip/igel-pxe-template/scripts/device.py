#!/usr/bin/env python3
"""Persistent PXE admission policy. Fail closed: only explicitly approved MACs get a PXE offer."""
import argparse
import ipaddress
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DATA = Path(os.environ.get('PXE_DATA', '/data'))
RULES = Path(os.environ.get('PXE_RULES', '/run/igel-pxe/policy.conf'))
MAC = re.compile(r'^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$')
STATES = ('approved', 'pending', 'converted', 'blocked')

def normalize(value):
    value = value.lower().replace('-', ':').strip()
    if not MAC.fullmatch(value):
        raise ValueError('Invalid MAC address: ' + value)
    return value

def connect():
    DATA.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DATA / 'devices.db')
    db.execute('CREATE TABLE IF NOT EXISTS devices (mac TEXT PRIMARY KEY, state TEXT NOT NULL, updated TEXT NOT NULL, note TEXT NOT NULL DEFAULT "")')
    db.execute('CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, mac TEXT, old_state TEXT, new_state TEXT, timestamp TEXT, note TEXT)')
    db.commit()
    return db

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def set_state(db, mac, state, note):
    old = db.execute('SELECT state FROM devices WHERE mac=?', (mac,)).fetchone()
    db.execute('INSERT INTO devices(mac,state,updated,note) VALUES(?,?,?,?) ON CONFLICT(mac) DO UPDATE SET state=excluded.state,updated=excluded.updated,note=excluded.note', (mac, state, now(), note))
    db.execute('INSERT INTO audit(mac,old_state,new_state,timestamp,note) VALUES(?,?,?,?,?)', (mac, old[0] if old else None, state, now(), note))
    db.commit()

def read_lines(name, validator):
    path = DATA / name
    if not path.exists():
        return set()
    result = set()
    for i, line in enumerate(path.read_text().splitlines(), 1):
        value = line.split('#', 1)[0].strip()
        if value:
            try:
                result.add(validator(value))
            except ValueError as exc:
                raise ValueError(f'{path}:{i}: {exc}') from exc
    return result

def render(db, subnet, netmask):
    network = ipaddress.IPv4Network((subnet, netmask), strict=False)
    if not (DATA / 'enabled.flag').exists():
        raise SystemExit('FAIL CLOSED: create /data/enabled.flag only after reviewing configuration')
    if not Path('/srv/tftp/grub/bootx64.efi').is_file():
        raise SystemExit('FAIL CLOSED: missing IGEL grub/bootx64.efi')
    if not Path('/srv/tftp/images/pxe-config.json').is_file():
        raise SystemExit('FAIL CLOSED: missing UMS-generated pxe-config.json')
    blocked = read_lines('blacklist-mac.txt', normalize)
    converted = read_lines('converted-mac.txt', normalize)
    pending = read_lines('pending-mac.txt', normalize)
    blocked_ips = read_lines('blacklist-ip.txt', lambda x: str(ipaddress.IPv4Address(x)))
    if blocked_ips:
        raise SystemExit('FAIL CLOSED: IP blacklist cannot be enforced reliably via ProxyDHCP. Configure exclusions on authoritative DHCP/network access control; remove IP entries only after doing so.')
    rows = db.execute('SELECT mac,state FROM devices').fetchall()
    eligible = sorted(mac for mac, state in rows if state == 'approved' and mac not in blocked | converted | pending)
    lines = [
        '# Generated from persistent registry. Do not edit.',
        f'dhcp-range={network.network_address},proxy,{network.netmask}',
        'dhcp-match=set:efi64,option:client-arch,7',
        'dhcp-match=set:efi64,option:client-arch,9',
    ]
    for mac in eligible:
        lines.append(f'dhcp-mac=set:igel_approved,{mac}')
    tftp_server = os.getenv('PXE_SERVER_IP', '99.99.99.99')
    ipaddress.IPv4Address(tftp_server)
    lines.append(
        f'pxe-service=tag:efi64,tag:igel_approved,'
        f'X86-64_EFI,"IGEL OS 12 (authorized)",'
        f'grub/bootx64.efi,{tftp_server}'
    )
    lines.append(
        f'dhcp-option=tag:igel_approved,option:tftp-server,'
        f'"{tftp_server}"'
    )
    RULES.parent.mkdir(parents=True, exist_ok=True)
    tmp = RULES.with_suffix('.tmp')
    tmp.write_text('\n'.join(lines) + '\n')
    tmp.replace(RULES)
    print(f'Policy rendered: {len(eligible)} approved MACs; other MACs get no PXE offer')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    s = sub.add_parser('set'); s.add_argument('mac'); s.add_argument('state', choices=STATES); s.add_argument('--note', default='')
    sub.add_parser('list')
    sub.add_parser('audit')
    s = sub.add_parser('render'); s.add_argument('--subnet', default=os.getenv('PXE_SUBNET', '192.168.1.0')); s.add_argument('--netmask', default=os.getenv('PXE_NETMASK', '255.255.255.0'))
    args = p.parse_args()
    with connect() as db:
        if args.command == 'set':
            set_state(db, normalize(args.mac), args.state, args.note)
            print('Updated. Run render and restart the container to apply the policy.')
        elif args.command == 'list':
            for row in db.execute('SELECT mac,state,updated,note FROM devices ORDER BY mac'):
                print('\t'.join(row))
        elif args.command == 'audit':
            for row in db.execute('SELECT id,mac,old_state,new_state,timestamp,note FROM audit ORDER BY id'):
                print('\t'.join(str(x or '') for x in row))
        else:
            render(db, args.subnet, args.netmask)

if __name__ == '__main__':
    main()
