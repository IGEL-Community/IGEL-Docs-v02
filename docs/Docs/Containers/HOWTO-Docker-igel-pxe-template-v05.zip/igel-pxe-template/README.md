# IGEL OS 12 Docker ProxyDHCP PXE Server

**Safety:** UEFI x64 only. Explicit MAC allowlist. All other MACs receive no PXE offer from this service. Does **not** block manual TFTP/HTTP downloads, rogue DHCP servers, or PXE options issued by your existing DHCP server. IP blacklist is fail-closed unless enforced externally. MACs can be spoofed. Test in an isolated provisioning VLAN before production.

Uses existing DHCP server and does not need DHCP server to provide TFTP server IP.

## Requirements

- Linux Docker host with host networking; no conflicting dnsmasq/TFTP/nginx services on ports UDP 67/69/4011 and TCP 80.
- Existing DHCP server. Avoid configuring its boot options for every endpoint; ensure it does not independently PXE-boot blocked devices.
- Official IGEL OS 12 PXE ZIP from IGEL App Portal and UMS-generated `pxe-config.json`.
- Endpoint Internet access to IGEL App Portal. Consult https://kb.igel.com/en/igel-os-base-system/current/how-to-deploy-igel-os-12-with-pxe

## Files to Review / Edit

1. `.env`: Environment variables.

```bash linenums="1"
PXE_SUBNET=10.0.0.0
PXE_NETMASK=255.255.255.0
```

2. `tftp/images/pxe-config.json`: UMS-generated PXE file (UMS: Apps -> Settings -> PXE Configuration -> Generate)

## Install

1. Can use the existing IGEL UMS pxe-config.json file or replace with your own version.
2. `chmod +x scripts/import-igel-pxe.sh && scripts/import-igel-pxe.sh /path/to/osc_VERSION_pxe.zip`

## Start Testing

1. `docker buildx bake --allow=network.host`
2. Obtain MAC address for test machine
3. `docker compose run --rm --entrypoint python3 igel-pxe /usr/local/bin/device.py set MY:MAC:ADDRESS:IS:THIS:STRING approved`
4. `docker compose up -d`
5. `docker compose logs -f`
6. PXE boot test machine

## Stop Testing

1. `docker stop igel-pxe`
2. `docker rm igel-pxe`
3. `docker images`
4. `docker rmi -f igel-pxe:bookworm`

## Registry management

Use `docker compose run --rm --entrypoint python3 igel-pxe /usr/local/bin/device.py ...` with:

- `set aa:bb:cc:dd:ee:ff approved` - authorize PXE boot
- `set aa:bb:cc:dd:ee:ff pending` - stop repeat PXE while installation is in progress
- `set aa:bb:cc:dd:ee:ff converted` - stop PXE after independently verifying installation
- `set aa:bb:cc:dd:ee:ff blocked` - explicitly blacklist
- `list` and `audit` - show registry and state changes

**After any registry or text-list change:** `docker compose restart igel-pxe`. The startup regenerates rules. The container will refuse to start if an IP blacklist is nonempty, or required boot assets are missing. This intentionally prevents silently ignoring blacklist policies.

## Static lists
- `data/blacklist-mac.txt` blocks listed MACs.
- `data/converted-mac.txt` and `data/pending-mac.txt` exclude MACs even when the registry says approved.
- `data/blacklist-ip.txt`: entries cause startup failure, because a ProxyDHCP server cannot reliably enforce exclusions based on client IP before the authoritative DHCP server allocates it. Implement IP exclusions on authoritative DHCP/NAC first, then remove entries from this file.

## Conversion tracking limitation
This package **does not** claim that a PXE download proves IGEL installation. Mark `pending` when starting deployment and `converted` after independent confirmation (for example from UMS inventory). Automatic UMS confirmation is **not implemented**, as it requires an authenticated, supported integration. Default is fail-closed for unknown MACs. SQLite database and lists persist under `data/`.

## Security notes
- The generated PXE config includes an App Portal token; TFTP has no authentication. Use a dedicated provisioning network and firewall restrictions.
- Protect the `data/` directory and backups.
- The HTTP/TFTP servers remain accessible to network clients; the MAC gate controls ProxyDHCP offers only, not direct file retrieval.
- Secure Boot compatibility depends on the IGEL-supplied boot assets and device firmware.
- The official ZIP and UMS token are intentionally not included in this archive.
