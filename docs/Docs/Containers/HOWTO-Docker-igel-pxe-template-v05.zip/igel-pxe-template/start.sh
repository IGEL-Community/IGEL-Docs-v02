#!/bin/sh
set -eu
python3 /usr/local/bin/device.py render --subnet "$PXE_SUBNET" --netmask "$PXE_NETMASK"
dnsmasq --test
nginx -t
nginx
exec dnsmasq --no-daemon --conf-file=/etc/dnsmasq.conf
