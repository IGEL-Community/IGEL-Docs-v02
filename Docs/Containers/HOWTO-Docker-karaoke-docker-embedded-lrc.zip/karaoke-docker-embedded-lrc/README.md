# Karaoke Docker with embedded LRC

Outputs:

```text
output/
├── song-karaoke.mp3
├── song-karaoke.lrc
└── song.html
```

The generated HTML embeds the LRC text directly. The MP3 stays external, so keep
`song.html` and `song-karaoke.mp3` in the same directory.

Build:

```bash
docker compose build --no-cache
```

Process All Songs:

```bash
docker compose run --rm karaoke
```

Process Single Song:

```bash
docker compose run --rm karaoke "song.mp3"
```

Open directly in default Browser:

```bash
xdg-open "$(realpath output/song.html)"
```
