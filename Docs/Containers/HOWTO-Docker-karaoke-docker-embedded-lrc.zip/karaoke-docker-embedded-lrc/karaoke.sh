#!/bin/sh
set -eu

INPUT_DIR="${INPUT_DIR:-/input}"
OUTPUT_DIR="${OUTPUT_DIR:-/output}"
MODEL_DIR="${MODEL_DIR:-/models}"
WHISPER_MODEL_DIR="${WHISPER_MODEL_DIR:-/whisper-models}"

PRESET="${PRESET:-karaoke}"
OUTPUT_FORMAT="${OUTPUT_FORMAT:-MP3}"
OUTPUT_BITRATE="${OUTPUT_BITRATE:-320k}"
LYRICS_MODE="${LYRICS_MODE:-auto}"
WHISPER_MODEL="${WHISPER_MODEL:-base}"
WHISPER_LANGUAGE="${WHISPER_LANGUAGE:-auto}"
WHISPER_THREADS="${WHISPER_THREADS:-4}"

mkdir -p "$INPUT_DIR" "$OUTPUT_DIR" "$MODEL_DIR" "$WHISPER_MODEL_DIR"

log() { printf '%s\n' "$*"; }

metadata_value() {
    ffprobe -v error \
      -show_entries "format_tags=$2" \
      -of default=noprint_wrappers=1:nokey=1 \
      "$1" 2>/dev/null | head -n 1 || true
}

fetch_lrclib() {
    input="$1"; lrc_out="$2"; base="$3"
    title="${TITLE:-}"; artist="${ARTIST:-}"
    [ -n "$title" ] || title="$(metadata_value "$input" title)"
    [ -n "$artist" ] || artist="$(metadata_value "$input" artist)"
    [ -n "$title" ] || title="$base"

    tmpjson="$(mktemp)"
    if [ -n "$artist" ]; then
        curl -fsSLG -H "User-Agent: karaoke-docker/4.0" \
          --data-urlencode "track_name=$title" \
          --data-urlencode "artist_name=$artist" \
          "https://lrclib.net/api/search" > "$tmpjson" || { rm -f "$tmpjson"; return 1; }
    else
        curl -fsSLG -H "User-Agent: karaoke-docker/4.0" \
          --data-urlencode "q=$title" \
          "https://lrclib.net/api/search" > "$tmpjson" || { rm -f "$tmpjson"; return 1; }
    fi

    if jq -e 'map(select(.syncedLyrics != null and .syncedLyrics != "")) | length > 0' "$tmpjson" >/dev/null 2>&1; then
        jq -r 'map(select(.syncedLyrics != null and .syncedLyrics != ""))[0].syncedLyrics' "$tmpjson" > "$lrc_out"
        rm -f "$tmpjson"
        return 0
    fi

    rm -f "$tmpjson"
    return 1
}

download_whisper_model() {
    model_path="$WHISPER_MODEL_DIR/ggml-${WHISPER_MODEL}.bin"
    if [ -s "$model_path" ]; then printf '%s\n' "$model_path"; return 0; fi
    url="https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-${WHISPER_MODEL}.bin"
    tmp="${model_path}.part"
    curl -fL --retry 3 --retry-delay 2 "$url" -o "$tmp"
    mv "$tmp" "$model_path"
    printf '%s\n' "$model_path"
}

find_stem() {
    find "$1" -maxdepth 1 -type f \( \
      -iname "*($2)*" -o \
      -iname "*_$2.*" -o \
      -iname "*-$2.*" -o \
      -iname "*$2*" \
    \) | head -n 1
}

make_whisper_lrc() {
    vocal_file="$1"; lrc_out="$2"
    model_path="$(download_whisper_model)"
    tmpwav="$(mktemp --suffix=.wav)"
    outbase="$(mktemp -u)"

    ffmpeg -hide_banner -loglevel error -y \
      -i "$vocal_file" -ar 16000 -ac 1 -c:a pcm_s16le "$tmpwav"

    whisper-cli \
      --model "$model_path" \
      --file "$tmpwav" \
      --language "$WHISPER_LANGUAGE" \
      --threads "$WHISPER_THREADS" \
      --no-gpu \
      --output-lrc \
      --output-file "$outbase"

    generated="${outbase}.lrc"
    [ -s "$generated" ] || { rm -f "$tmpwav" "$generated"; return 1; }
    mv "$generated" "$lrc_out"
    rm -f "$tmpwav"
}

html_escape() {
    printf '%s' "$1" | sed \
      -e 's/&/\&amp;/g' \
      -e 's/</\&lt;/g' \
      -e 's/>/\&gt;/g' \
      -e 's/"/\&quot;/g'
}

generate_html() {
    audio_filename="$1"; lrc_file="$2"; html_out="$3"; title="$4"; artist="$5"
    esc_title="$(html_escape "$title")"
    esc_artist="$(html_escape "$artist")"
    embedded_lrc="$(jq -Rs . "$lrc_file")"

    cat > "$html_out" <<EOF
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc_title} - Karaoke</title>
<style>
body{margin:0;min-height:100vh;background:#09090b;color:#fafafa;font-family:system-ui,sans-serif;display:flex;flex-direction:column;overflow:hidden}
header{text-align:center;padding:1rem}.artist{opacity:.7}
#lyrics{flex:1;overflow-y:auto;scroll-behavior:smooth;padding:35vh 1.5rem;text-align:center;scrollbar-width:none}
.line{max-width:1100px;margin:1rem auto;color:#71717a;font-weight:650;font-size:clamp(1.3rem,3.6vw,3.2rem);line-height:1.18;opacity:.52;transition:.18s}
.line.near{color:#a1a1aa;opacity:.78}.line.active{color:#fff;opacity:1;transform:scale(1.06)}
.controls{padding:.75rem 1rem 1rem}audio{display:block;width:min(1000px,100%);margin:0 auto}
.buttons{display:flex;justify-content:center;gap:.75rem;margin-top:.65rem}
button{border:1px solid #3f3f46;background:#18181b;color:#fafafa;border-radius:.65rem;padding:.6rem 1rem;font:inherit}
</style>
</head>
<body>
<header><h1>${esc_title}</h1><div class="artist">${esc_artist}</div></header>
<main id="lyrics"></main>
<div class="controls">
<audio id="audio" controls preload="metadata"><source src="./${audio_filename}"></audio>
<div class="buttons"><button id="restart">Restart</button><button id="fullscreen">Fullscreen</button></div>
</div>
<script>
const embeddedLrc = ${embedded_lrc};
const audio=document.getElementById("audio");
const lyricsEl=document.getElementById("lyrics");
let lines=[],activeIndex=-1;

function parseLrc(text){
 const parsed=[]; const re=/\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?\\](.*)/g;
 for(const raw of text.split(/\\r?\\n/)){
  re.lastIndex=0; let m;
  while((m=re.exec(raw))!==null){
   const min=Number(m[1]),sec=Number(m[2]),f=m[3]||"0";
   const frac=f.length===1?Number(f)/10:f.length===2?Number(f)/100:Number(f)/1000;
   parsed.push({time:min*60+sec+frac,text:m[4].trim()||"♪"});
  }
 }
 return parsed.sort((a,b)=>a.time-b.time);
}
function renderLyrics(){
 lyricsEl.innerHTML="";
 lines.forEach((line,i)=>{const d=document.createElement("div");d.className="line";d.dataset.index=i;d.textContent=line.text;lyricsEl.appendChild(d);});
}
function updateLyrics(){
 const t=audio.currentTime; let idx=-1;
 for(let i=0;i<lines.length;i++){if(lines[i].time<=t+.03)idx=i;else break;}
 if(idx===activeIndex)return; activeIndex=idx;
 document.querySelectorAll(".line").forEach((el,i)=>{el.classList.toggle("active",i===idx);el.classList.toggle("near",i===idx-1||i===idx+1);});
 if(idx>=0){const el=document.querySelector('.line[data-index="'+idx+'"]');if(el)el.scrollIntoView({behavior:"smooth",block:"center"});}
}
lines=parseLrc(embeddedLrc); renderLyrics(); updateLyrics();
audio.addEventListener("timeupdate",updateLyrics); audio.addEventListener("seeked",updateLyrics);
document.getElementById("restart").onclick=()=>{audio.currentTime=0;audio.play();};
document.getElementById("fullscreen").onclick=async()=>{if(!document.fullscreenElement)await document.documentElement.requestFullscreen();else await document.exitFullscreen();};
document.addEventListener("keydown",e=>{
 if(e.code==="Space"){e.preventDefault();audio.paused?audio.play():audio.pause();}
 if(e.code==="ArrowLeft")audio.currentTime=Math.max(0,audio.currentTime-5);
 if(e.code==="ArrowRight")audio.currentTime=Math.min(audio.duration||Infinity,audio.currentTime+5);
});
</script>
</body>
</html>
EOF
}

process_file() {
    input="$1"
    [ -f "$input" ] || { log "ERROR: $input not found"; exit 2; }

    filename="$(basename "$input")"
    base="${filename%.*}"
    tmpdir="$(mktemp -d)"
    lrc_out="$OUTPUT_DIR/${base}-karaoke.lrc"
    trap 'rm -rf "$tmpdir"' EXIT INT TERM

    title="${TITLE:-}"; artist="${ARTIST:-}"
    [ -n "$title" ] || title="$(metadata_value "$input" title)"
    [ -n "$artist" ] || artist="$(metadata_value "$input" artist)"
    [ -n "$title" ] || title="$base"

    lrclib_ok=0
    case "$LYRICS_MODE" in
      auto|lrclib) fetch_lrclib "$input" "$lrc_out" "$base" && lrclib_ok=1 || true ;;
      whisper|off) ;;
      *) log "ERROR: invalid LYRICS_MODE"; exit 4 ;;
    esac

    audio-separator "$input" \
      --ensemble_preset "$PRESET" \
      --output_format "$OUTPUT_FORMAT" \
      --output_bitrate "$OUTPUT_BITRATE" \
      --output_dir "$tmpdir" \
      --model_file_dir "$MODEL_DIR"

    instrumental="$(find_stem "$tmpdir" Instrumental)"
    vocals="$(find_stem "$tmpdir" Vocals)"
    [ -n "${instrumental:-}" ] || instrumental="$(find "$tmpdir" -maxdepth 1 -type f ! -iname "*vocal*" | head -n 1)"
    [ -n "${instrumental:-}" ] || { log "ERROR: no instrumental stem"; exit 3; }

    ext="${instrumental##*.}"
    karaoke_out="$OUTPUT_DIR/${base}-karaoke.${ext}"
    mv "$instrumental" "$karaoke_out"

    case "$LYRICS_MODE" in
      auto)
        if [ "$lrclib_ok" -eq 0 ] && [ -n "${vocals:-}" ] && [ -f "$vocals" ]; then make_whisper_lrc "$vocals" "$lrc_out" || true; fi ;;
      whisper)
        [ -n "${vocals:-}" ] && [ -f "$vocals" ] && make_whisper_lrc "$vocals" "$lrc_out" || true ;;
    esac

    if [ -s "$lrc_out" ]; then
        html_out="$OUTPUT_DIR/${base}-karaoke.html"
        generate_html "$(basename "$karaoke_out")" "$lrc_out" "$html_out" "$title" "$artist"
    fi

    rm -rf "$tmpdir"; trap - EXIT INT TERM
    log "Done:"
    log "  Karaoke: $karaoke_out"
    [ -s "$lrc_out" ] && log "  Lyrics:  $lrc_out"
    [ -f "$OUTPUT_DIR/${base}-karaoke.html" ] && log "  Player:  $OUTPUT_DIR/${base}-karaoke.html"
}

if [ "$#" -gt 0 ]; then
  for arg in "$@"; do
    case "$arg" in /*) input="$arg" ;; *) input="$INPUT_DIR/$arg" ;; esac
    process_file "$input"
  done
else
  for input in "$INPUT_DIR"/*; do [ -f "$input" ] && process_file "$input"; done
fi
