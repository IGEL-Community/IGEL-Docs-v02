#!/bin/bash
set -eu
[ "$#" -eq 1 ] || { echo 'Usage: scripts/import-igel-pxe.sh /path/to/osc_VERSION_pxe.zip' >&2; exit 2; }
[ -f "$1" ] || { echo "File not found: $1" >&2; exit 3; }
[ -f $(dirname "$1")/pxe-config.json ] || { echo "pxe-config.json not found" >&2; exit 4; }
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=$(mktemp -d)
PATH=$PATH:$BASE/scripts
trap 'rm -rf "$TMP"' EXIT
unzip -q "$1" -d "$TMP"
TFTP=$(find "$TMP" -type d -name tftp -print -quit)
WEB=$(find "$TMP" -type d -name webserver -print -quit)
[ -n "$TFTP" ] && [ -n "$WEB" ] || { echo 'Missing tftp/ or webserver/ in ZIP' >&2; exit 1; }
mkdir -p "$BASE/tftp" "$BASE/http"
cp -a "$TFTP/." "$BASE/tftp/"
cp -a "$WEB/." "$BASE/http/"
cp -a $(dirname "$1")/pxe-config.json "$BASE/tftp/images/"
echo 'Imported IGEL PXE assets. Place UMS-generated JSON at tftp/images/pxe-config.json.'

IGEL_DOCKER_MACHINE=$(getmyip)

# patch igel-pxe-initrd to use the docker host IP address for tftp_address
mkdir -p initrd-work
zstd -dc tftp/images/igel-pxe-initrd > initrd-work/initrd.raw
mkdir -p initrd-work/rootfs
pushd .
cd initrd-work/rootfs
cpio -idm --no-absolute-filenames < ../initrd.raw
cp -a etc/udhcpc/default.script etc/udhcpc/default.script.original
sed -i "/tftp_address/a [ -s /tmp/tftp_address ] || echo \"${IGEL_DOCKER_MACHINE}\" > /tmp/tftp_address" etc/udhcpc/default.script
find . -print0 | cpio --null -o -H newc   | zstd -T0 -19   > ../igel-pxe-initrd.patched
popd
mv tftp/images/igel-pxe-initrd tftp/images/igel-pxe-initrd.original
cp -a initrd-work/igel-pxe-initrd.patched tftp/images/igel-pxe-initrd

# patch pxe-config.json to use the docker host IP address
sed -i \
  's|{"partitions":\["http://your_link_here_1","http://your_link_here_2"\]}|{"partitions":["http://99.99.99.99/osc.bspl","http://99.99.99.99/osc.nvgfx","http://99.99.99.99/osc.sys"]}|g' \
  tftp/images/pxe-config.json
sed -i "s|99\.99\.99\.99|${IGEL_DOCKER_MACHINE}|g" tftp/images/pxe-config.json

# patch .env to use the docker host IP address
sed -i "s|99\.99\.99\.99|${IGEL_DOCKER_MACHINE}|g" .env 

# patch scripts/device.py to use the docker host IP address
sed -i "s|99\.99\.99\.99|${IGEL_DOCKER_MACHINE}|g" scripts/device.py

# get network information
INTERFACE=$(ip -4 route show default | awk 'NR==1 {print $5}')
IP_CIDR=$(ip -4 -o addr show dev "$INTERFACE" scope global | awk 'NR==1 {print $4}')

# Extract IP address and CIDR prefix
IP_ADDRESS=${IP_CIDR%/*}
PREFIX=${IP_CIDR#*/}

# Get network address and netmask
NETWORK_ADDRESS=$(ipcalc -n "$IP_CIDR")
NETMASK=$(ipcalc -m "$IP_CIDR")

# Add CIDR prefix to network address
NETWORK="${NETWORK_ADDRESS}/${PREFIX}"

echo "Interface:       $INTERFACE"
echo "IP/CIDR:         $IP_CIDR"
echo "IP:              $IP_ADDRESS"
echo "Network:         $NETWORK"
echo "Network Address: $NETWORK_ADDRESS"
echo "Netmask:         $NETMASK"

sed -i "s|PXE_SUBNET=.*|PXE_SUBNET=${NETWORK_ADDRESS}|" .env
sed -i "s|PXE_NETMASK=.*|PXE_NETMASK=${NETMASK}|" .env


#docker buildx bake --allow=network.host
#docker compose run --rm --entrypoint python3   igel-pxe /usr/local/bin/device.py   set   68:45:F1:39:1E:31   approved
#docker compose up -d
#docker compose logs -f